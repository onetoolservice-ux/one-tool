#!/bin/bash

echo "🧹 Starting FULL Budget Ultimate Cleanup..."

# -------------------------------------------
# 1) DELETE ALL BACKUP FOLDERS (safe)
# -------------------------------------------
echo "🗑 Removing backup folders..."

rm -rf _backup_budget_ultimate
rm -rf _backup_budget_ultimate_auto
rm -rf app/tools/finance/budget-ultimate.bak_*
rm -rf app/tools/finance/budget-ultimate_backup_*
rm -rf app/tools/finance/budget-ultimate.bak_userdata_*

# ANY folder that contains .bak files inside budget-ultimate
find app/tools/finance/budget-ultimate -type d -name "*bak*" -exec rm -rf {} +

# -------------------------------------------
# 2) DELETE ALL .bak FILES IN PROJECT
# -------------------------------------------
echo "🗑 Removing all .bak files..."

find . -type f -name "*.bak" -delete
find . -type f -name "*.bak_*" -delete

# -------------------------------------------
# 3) DELETE ALL DUPLICATE SAMPLE/STORAGE FILES
# -------------------------------------------
echo "🗑 Cleaning duplicate utils files..."

find app/tools/finance/budget-ultimate -type f -name "sampleData.ts.bak*" -delete
find app/tools/finance/budget-ultimate -type f -name "storage.ts.bak*" -delete
find app/tools/finance/budget-ultimate -type f -name "sampleCategories.ts.bak*" -delete

# -------------------------------------------
# 4) REMOVE EMPTY DIRECTORIES
# -------------------------------------------
echo "🧺 Removing empty directories..."

find app/tools/finance/budget-ultimate -type d -empty -delete

# -------------------------------------------
# 5) DONE
# -------------------------------------------
echo ""
echo "✅ Cleanup COMPLETE!"
echo "🚀 All backups, .bak files, duplicates, and old auto-generated folders are removed."
echo "✨ Your Budget Ultimate module now contains ONLY clean, real working files."
