module.exports = [
"[project]/.next-internal/server/app/tools/finance/budget-ultimate/analytics/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_tools_finance_budget-ultimate_analytics_page_actions_3091d0ca.js.map