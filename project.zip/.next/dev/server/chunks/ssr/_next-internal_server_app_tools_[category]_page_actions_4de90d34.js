module.exports = [
"[project]/.next-internal/server/app/tools/[category]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_tools_%5Bcategory%5D_page_actions_4de90d34.js.map