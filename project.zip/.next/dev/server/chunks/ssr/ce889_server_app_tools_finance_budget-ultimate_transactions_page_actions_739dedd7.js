module.exports = [
"[project]/.next-internal/server/app/tools/finance/budget-ultimate/transactions/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_tools_finance_budget-ultimate_transactions_page_actions_739dedd7.js.map