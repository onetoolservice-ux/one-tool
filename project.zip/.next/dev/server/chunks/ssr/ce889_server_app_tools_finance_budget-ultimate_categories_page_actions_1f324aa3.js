module.exports = [
"[project]/.next-internal/server/app/tools/finance/budget-ultimate/categories/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_tools_finance_budget-ultimate_categories_page_actions_1f324aa3.js.map