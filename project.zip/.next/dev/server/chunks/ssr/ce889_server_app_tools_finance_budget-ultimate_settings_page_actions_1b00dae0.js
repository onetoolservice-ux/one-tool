module.exports = [
"[project]/.next-internal/server/app/tools/finance/budget-ultimate/settings/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_tools_finance_budget-ultimate_settings_page_actions_1b00dae0.js.map