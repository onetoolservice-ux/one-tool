module.exports = [
"[project]/.next-internal/server/app/tools/finance/budget-ultimate/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_tools_finance_budget-ultimate_page_actions_90268031.js.map