module.exports = [
"[project]/.next-internal/server/app/tools/[category]/[tool]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_tools_%5Bcategory%5D_%5Btool%5D_page_actions_8c388b64.js.map