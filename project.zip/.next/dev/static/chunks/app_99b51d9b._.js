(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/tools/finance/budget-ultimate/storage.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LS_KEYS",
    ()=>LS_KEYS,
    "readLS",
    ()=>readLS,
    "writeLS",
    ()=>writeLS
]);
const LS_KEYS = {
    TRANSACTIONS: "ots_budget_txns_v2",
    CATEGORIES: "ots_budget_categories_v1",
    VARIANTS: "ots_budget_variants_v1",
    SETTINGS: "ots_budget_settings_v1"
};
function readLS(key, fallback = null) {
    try {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
        return fallback;
    }
}
function writeLS(key, value) {
    try {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
    // noop
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/uid.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "uid",
    ()=>uid
]);
function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/utils/sampleData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Local demo + persistence helpers for Budget Ultimate
 * - Uses local LS_KEYS via ../storage
 * - Uses shared uid from app/utils/uid.ts (relative path computed by script)
 */ __turbopack_context__.s([
    "addTransaction",
    ()=>addTransaction,
    "clearTransactions",
    ()=>clearTransactions,
    "loadCategories",
    ()=>loadCategories,
    "loadTransactions",
    ()=>loadTransactions,
    "saveCategories",
    ()=>saveCategories,
    "saveTransactions",
    ()=>saveTransactions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/storage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/uid.ts [app-client] (ecmascript)");
;
;
// demo transactions
const DEMO_TXNS = [
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        date: "2025-05-01",
        type: "Expense",
        category: "Groceries",
        desc: "Milk + Vegetables",
        amount: 550,
        status: "Posted"
    },
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        date: "2025-05-01",
        type: "Income",
        category: "Salary",
        desc: "Monthly Income",
        amount: 48000,
        status: "Posted"
    },
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        date: "2025-04-20",
        type: "Expense",
        category: "Utilities",
        desc: "Electricity Bill",
        amount: 2200,
        status: "Posted"
    },
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        date: "2025-03-15",
        type: "Expense",
        category: "Transport",
        desc: "Fuel",
        amount: 1800,
        status: "Posted"
    }
];
const DEMO_CATS = [
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        name: "Groceries",
        type: "Expense",
        color: "#F97316"
    },
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        name: "Utilities",
        type: "Expense",
        color: "#EF4444"
    },
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        name: "Transport",
        type: "Expense",
        color: "#06B6D4"
    },
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        name: "Salary",
        type: "Income",
        color: "#10B981"
    }
];
function loadTransactions() {
    const stored = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].TRANSACTIONS, null);
    if (stored && Array.isArray(stored) && stored.length) return stored;
    // seed demo
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["writeLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].TRANSACTIONS, DEMO_TXNS);
    return DEMO_TXNS;
}
function saveTransactions(items) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["writeLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].TRANSACTIONS, items);
}
function clearTransactions() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["writeLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].TRANSACTIONS, []);
}
function loadCategories() {
    const stored = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].CATEGORIES, null);
    if (stored && Array.isArray(stored) && stored.length) return stored;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["writeLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].CATEGORIES, DEMO_CATS);
    return DEMO_CATS;
}
function saveCategories(items) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["writeLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].CATEGORIES, items);
}
function addTransaction(tx) {
    const all = loadTransactions();
    const row = {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        date: tx.date ?? new Date().toISOString().slice(0, 10),
        type: tx.type ?? "Expense",
        category: tx.category ?? "Uncategorized",
        desc: tx.desc ?? "",
        amount: Number(tx.amount ?? 0),
        status: tx.status ?? "Draft"
    };
    const out = [
        row,
        ...all
    ];
    saveTransactions(out);
    return row;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AnalyticTile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$LineChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/chart/LineChart.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/cartesian/Line.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/component/ResponsiveContainer.js [app-client] (ecmascript)");
"use client";
;
;
;
function AnalyticTile(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "8a42b6150661b25d75e91c0f443ccb2abca94fc85fd04e1f3cd912a986b4c8f5") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8a42b6150661b25d75e91c0f443ccb2abca94fc85fd04e1f3cd912a986b4c8f5";
    }
    const { title, value, colorClass: t1, trendText: t2, data: t3, onClick } = t0;
    const colorClass = t1 === undefined ? "" : t1;
    const trendText = t2 === undefined ? "" : t2;
    let t4;
    if ($[1] !== t3) {
        t4 = t3 === undefined ? [] : t3;
        $[1] = t3;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    const data = t4;
    let t5;
    if ($[3] !== title) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-xs text-slate-500",
            children: title
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 46,
            columnNumber: 10
        }, this);
        $[3] = title;
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    const t6 = `text-2xl font-bold mt-1 ${colorClass}`;
    let t7;
    if ($[5] !== t6 || $[6] !== value) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t6,
            children: value
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 55,
            columnNumber: 10
        }, this);
        $[5] = t6;
        $[6] = value;
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    let t8;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Line"], {
            type: "monotone",
            dataKey: "amt",
            stroke: "currentColor",
            strokeWidth: 2,
            dot: false
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 64,
            columnNumber: 10
        }, this);
        $[8] = t8;
    } else {
        t8 = $[8];
    }
    let t9;
    if ($[9] !== data) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-10 mt-2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResponsiveContainer"], {
                width: "100%",
                height: "100%",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$LineChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineChart"], {
                    data: data,
                    children: t8
                }, void 0, false, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
                    lineNumber: 71,
                    columnNumber: 85
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
                lineNumber: 71,
                columnNumber: 37
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[9] = data;
        $[10] = t9;
    } else {
        t9 = $[10];
    }
    let t10;
    if ($[11] !== trendText) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-xs text-slate-500 mt-1",
            children: trendText
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 79,
            columnNumber: 11
        }, this);
        $[11] = trendText;
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    let t11;
    if ($[13] !== onClick || $[14] !== t10 || $[15] !== t5 || $[16] !== t7 || $[17] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            onClick: onClick,
            className: "p-4 border rounded-lg bg-white hover:shadow-md transition cursor-pointer",
            children: [
                t5,
                t7,
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 87,
            columnNumber: 11
        }, this);
        $[13] = onClick;
        $[14] = t10;
        $[15] = t5;
        $[16] = t7;
        $[17] = t9;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    return t11;
}
_c = AnalyticTile;
var _c;
__turbopack_context__.k.register(_c, "AnalyticTile");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OverviewPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/utils/sampleData.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/funnel.js [app-client] (ecmascript) <export default as Filter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chart-column.js [app-client] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$panel$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutPanelLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layout-panel-left.js [app-client] (ecmascript) <export default as LayoutPanelLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function OverviewPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(110);
    if ($[0] !== "18c4cd46fd7dd39b7262abf11b4fc6791cb1d840ddf2ae56cc6240dc62c9c45a") {
        for(let $i = 0; $i < 110; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "18c4cd46fd7dd39b7262abf11b4fc6791cb1d840ddf2ae56cc6240dc62c9c45a";
    }
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t0;
    if ($[1] !== router) {
        t0 = ({
            "OverviewPage[handleKPI]": ()=>{
                router.push("/tools/finance/budget-ultimate/analytics?view=kpi&year=2025&category=all&type=all");
            }
        })["OverviewPage[handleKPI]"];
        $[1] = router;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const handleKPI = t0;
    let t1;
    if ($[3] !== router) {
        t1 = ({
            "OverviewPage[handleDetailed]": ()=>{
                router.push("/tools/finance/budget-ultimate/analytics?view=detailed&year=2025");
            }
        })["OverviewPage[handleDetailed]"];
        $[3] = router;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    const handleDetailed = t1;
    const [groupOpen, setGroupOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t2;
    if ($[5] !== router) {
        t2 = ({
            "OverviewPage[handleGroup]": (option)=>{
                router.push(`/tools/finance/budget-ultimate/analytics?group=${option}&view=grouped`);
                setGroupOpen(false);
            }
        })["OverviewPage[handleGroup]"];
        $[5] = router;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    const handleGroup = t2;
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [categoryFilter, setCategoryFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const [typeFilter, setTypeFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[7] !== categoryFilter || $[8] !== groupOpen || $[9] !== handleDetailed || $[10] !== handleGroup || $[11] !== handleKPI || $[12] !== search || $[13] !== typeFilter) {
        const income = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleTransactions"].filter(_OverviewPageSampleTransactionsFilter).reduce(_OverviewPageAnonymous, 0);
        const expense = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleTransactions"].filter(_OverviewPageSampleTransactionsFilter2).reduce(_OverviewPageAnonymous2, 0);
        const balance = income - expense;
        const savingsRate = income ? (balance / income * 100).toFixed(1) : "0";
        let t16;
        if ($[27] !== search) {
            t16 = ({
                "OverviewPage[sampleTransactions.filter()]": (t_1)=>search ? t_1.desc.toLowerCase().includes(search.toLowerCase()) : true
            })["OverviewPage[sampleTransactions.filter()]"];
            $[27] = search;
            $[28] = t16;
        } else {
            t16 = $[28];
        }
        let t17;
        if ($[29] !== categoryFilter) {
            t17 = ({
                "OverviewPage[(anonymous)()]": (t_2)=>categoryFilter === "all" ? true : t_2.category === categoryFilter
            })["OverviewPage[(anonymous)()]"];
            $[29] = categoryFilter;
            $[30] = t17;
        } else {
            t17 = $[30];
        }
        let t18;
        if ($[31] !== typeFilter) {
            t18 = ({
                "OverviewPage[(anonymous)()]": (t_3)=>typeFilter === "all" ? true : t_3.type === typeFilter
            })["OverviewPage[(anonymous)()]"];
            $[31] = typeFilter;
            $[32] = t18;
        } else {
            t18 = $[32];
        }
        const filtered = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleTransactions"].filter(t16).filter(t17).filter(t18);
        t12 = "space-y-8 pb-8";
        let t19;
        if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Income",
                value: `₹${income.toLocaleString()}`,
                colorClass: "text-emerald-600",
                trendText: "+12% vs last month",
                data: [
                    {
                        amt: 2000
                    },
                    {
                        amt: 3500
                    },
                    {
                        amt: 5000
                    },
                    {
                        amt: 4200
                    },
                    {
                        amt: 6000
                    }
                ]
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 114,
                columnNumber: 13
            }, this);
            $[33] = t19;
        } else {
            t19 = $[33];
        }
        let t20;
        if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
            t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Expense",
                value: `₹${expense.toLocaleString()}`,
                colorClass: "text-rose-600",
                trendText: "-5% variance",
                data: [
                    {
                        amt: 400
                    },
                    {
                        amt: 320
                    },
                    {
                        amt: 500
                    },
                    {
                        amt: 450
                    },
                    {
                        amt: 380
                    }
                ]
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 131,
                columnNumber: 13
            }, this);
            $[34] = t20;
        } else {
            t20 = $[34];
        }
        let t21;
        if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
            t21 = balance.toLocaleString();
            $[35] = t21;
        } else {
            t21 = $[35];
        }
        let t22;
        if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
            t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Balance",
                value: `₹${t21}`,
                colorClass: "text-blue-600",
                trendText: "Stable",
                data: [
                    {
                        amt: balance - 2000
                    },
                    {
                        amt: balance - 1000
                    },
                    {
                        amt: balance
                    }
                ]
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 155,
                columnNumber: 13
            }, this);
            $[36] = t22;
        } else {
            t22 = $[36];
        }
        let t23;
        if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
            t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Categories",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleCategories"].length,
                colorClass: "text-slate-900",
                trendText: "Active groups",
                data: [
                    {
                        amt: 3
                    },
                    {
                        amt: 4
                    },
                    {
                        amt: 5
                    },
                    {
                        amt: 3
                    },
                    {
                        amt: 4
                    }
                ]
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 168,
                columnNumber: 13
            }, this);
            $[37] = t23;
        } else {
            t23 = $[37];
        }
        if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 md:grid-cols-5 gap-4",
                children: [
                    t19,
                    t20,
                    t22,
                    t23,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        title: "Savings Rate",
                        value: `${savingsRate}%`,
                        colorClass: "text-indigo-600",
                        trendText: "Income saved",
                        data: [
                            {
                                amt: 5
                            },
                            {
                                amt: 8
                            },
                            {
                                amt: 10
                            },
                            {
                                amt: 7
                            },
                            {
                                amt: 11
                            }
                        ]
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 184,
                        columnNumber: 88
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 184,
                columnNumber: 13
            }, this);
            $[38] = t13;
        } else {
            t13 = $[38];
        }
        let t24;
        if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
            t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-lg font-semibold",
                children: "Transactions"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 201,
                columnNumber: 13
            }, this);
            $[39] = t24;
        } else {
            t24 = $[39];
        }
        let t25;
        if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
            t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"], {
                size: 16
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 208,
                columnNumber: 13
            }, this);
            $[40] = t25;
        } else {
            t25 = $[40];
        }
        let t26;
        if ($[41] !== handleKPI) {
            t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleKPI,
                className: "px-3 py-2 border rounded-lg flex items-center gap-2 hover:bg-slate-100",
                children: [
                    t25,
                    " KPI Dashboard"
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 215,
                columnNumber: 13
            }, this);
            $[41] = handleKPI;
            $[42] = t26;
        } else {
            t26 = $[42];
        }
        let t27;
        if ($[43] === Symbol.for("react.memo_cache_sentinel")) {
            t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$panel$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutPanelLeft$3e$__["LayoutPanelLeft"], {
                size: 16
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 223,
                columnNumber: 13
            }, this);
            $[43] = t27;
        } else {
            t27 = $[43];
        }
        let t28;
        if ($[44] !== handleDetailed) {
            t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleDetailed,
                className: "px-3 py-2 border rounded-lg flex items-center gap-2 hover:bg-slate-100",
                children: [
                    t27,
                    " Detailed Analytics"
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 230,
                columnNumber: 13
            }, this);
            $[44] = handleDetailed;
            $[45] = t28;
        } else {
            t28 = $[45];
        }
        let t29;
        if ($[46] !== groupOpen) {
            t29 = ({
                "OverviewPage[<button>.onClick]": ()=>setGroupOpen(!groupOpen)
            })["OverviewPage[<button>.onClick]"];
            $[46] = groupOpen;
            $[47] = t29;
        } else {
            t29 = $[47];
        }
        let t30;
        if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
            t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                size: 14
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 248,
                columnNumber: 13
            }, this);
            $[48] = t30;
        } else {
            t30 = $[48];
        }
        let t31;
        if ($[49] !== t29) {
            t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: t29,
                className: "px-3 py-2 border rounded-lg flex items-center gap-2 hover:bg-slate-100",
                children: [
                    "Group by… ",
                    t30
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 255,
                columnNumber: 13
            }, this);
            $[49] = t29;
            $[50] = t31;
        } else {
            t31 = $[50];
        }
        let t32;
        if ($[51] !== groupOpen || $[52] !== handleGroup) {
            t32 = groupOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute right-0 mt-2 w-40 bg-white border rounded-lg shadow-lg z-50",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: {
                            "OverviewPage[<button>.onClick]": ()=>handleGroup("category")
                        }["OverviewPage[<button>.onClick]"],
                        className: "px-4 py-2 w-full text-left hover:bg-slate-100",
                        children: "Category"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 263,
                        columnNumber: 112
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: {
                            "OverviewPage[<button>.onClick]": ()=>handleGroup("type")
                        }["OverviewPage[<button>.onClick]"],
                        className: "px-4 py-2 w-full text-left hover:bg-slate-100",
                        children: "Type"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 265,
                        columnNumber: 121
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: {
                            "OverviewPage[<button>.onClick]": ()=>handleGroup("month")
                        }["OverviewPage[<button>.onClick]"],
                        className: "px-4 py-2 w-full text-left hover:bg-slate-100",
                        children: "Month"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 267,
                        columnNumber: 117
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 263,
                columnNumber: 26
            }, this);
            $[51] = groupOpen;
            $[52] = handleGroup;
            $[53] = t32;
        } else {
            t32 = $[53];
        }
        let t33;
        if ($[54] !== t31 || $[55] !== t32) {
            t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    t31,
                    t32
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 278,
                columnNumber: 13
            }, this);
            $[54] = t31;
            $[55] = t32;
            $[56] = t33;
        } else {
            t33 = $[56];
        }
        if ($[57] !== t26 || $[58] !== t28 || $[59] !== t33) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    t24,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 text-sm relative",
                        children: [
                            t26,
                            t28,
                            t33
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 286,
                        columnNumber: 69
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 286,
                columnNumber: 13
            }, this);
            $[57] = t26;
            $[58] = t28;
            $[59] = t33;
            $[60] = t14;
        } else {
            t14 = $[60];
        }
        let t34;
        if ($[61] === Symbol.for("react.memo_cache_sentinel")) {
            t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                size: 16,
                className: "absolute left-3 top-2.5 text-slate-400"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 296,
                columnNumber: 13
            }, this);
            $[61] = t34;
        } else {
            t34 = $[61];
        }
        let t35;
        if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
            t35 = ({
                "OverviewPage[<input>.onChange]": (e)=>setSearch(e.target.value)
            })["OverviewPage[<input>.onChange]"];
            $[62] = t35;
        } else {
            t35 = $[62];
        }
        let t36;
        if ($[63] !== search) {
            t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full md:w-80",
                children: [
                    t34,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        className: "w-full pl-10 pr-3 py-2 border rounded-lg text-sm",
                        placeholder: "Search description or category...",
                        value: search,
                        onChange: t35
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 312,
                        columnNumber: 59
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 312,
                columnNumber: 13
            }, this);
            $[63] = search;
            $[64] = t36;
        } else {
            t36 = $[64];
        }
        let t37;
        if ($[65] === Symbol.for("react.memo_cache_sentinel")) {
            t37 = ({
                "OverviewPage[<select>.onChange]": (e_0)=>setCategoryFilter(e_0.target.value)
            })["OverviewPage[<select>.onChange]"];
            $[65] = t37;
        } else {
            t37 = $[65];
        }
        let t38;
        let t39;
        let t40;
        if ($[66] === Symbol.for("react.memo_cache_sentinel")) {
            t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                value: "all",
                children: "All Categories"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 331,
                columnNumber: 13
            }, this);
            t39 = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleCategories"].map(_OverviewPageSampleCategoriesMap);
            t40 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                value: "more",
                children: "+ Add more…"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 333,
                columnNumber: 13
            }, this);
            $[66] = t38;
            $[67] = t39;
            $[68] = t40;
        } else {
            t38 = $[66];
            t39 = $[67];
            t40 = $[68];
        }
        let t41;
        if ($[69] !== categoryFilter) {
            t41 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                value: categoryFilter,
                onChange: t37,
                className: "border px-3 py-2 rounded-lg text-sm",
                children: [
                    t38,
                    t39,
                    t40
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 344,
                columnNumber: 13
            }, this);
            $[69] = categoryFilter;
            $[70] = t41;
        } else {
            t41 = $[70];
        }
        let t42;
        if ($[71] === Symbol.for("react.memo_cache_sentinel")) {
            t42 = ({
                "OverviewPage[<select>.onChange]": (e_1)=>setTypeFilter(e_1.target.value)
            })["OverviewPage[<select>.onChange]"];
            $[71] = t42;
        } else {
            t42 = $[71];
        }
        let t43;
        let t44;
        let t45;
        let t46;
        if ($[72] === Symbol.for("react.memo_cache_sentinel")) {
            t43 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                value: "all",
                children: "All Types"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 364,
                columnNumber: 13
            }, this);
            t44 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                value: "Income",
                children: "Income"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 365,
                columnNumber: 13
            }, this);
            t45 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                value: "Expense",
                children: "Expense"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 366,
                columnNumber: 13
            }, this);
            t46 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                value: "more",
                children: "+ New Type…"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 367,
                columnNumber: 13
            }, this);
            $[72] = t43;
            $[73] = t44;
            $[74] = t45;
            $[75] = t46;
        } else {
            t43 = $[72];
            t44 = $[73];
            t45 = $[74];
            t46 = $[75];
        }
        let t47;
        if ($[76] !== typeFilter) {
            t47 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                value: typeFilter,
                onChange: t42,
                className: "border px-3 py-2 rounded-lg text-sm",
                children: [
                    t43,
                    t44,
                    t45,
                    t46
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 380,
                columnNumber: 13
            }, this);
            $[76] = typeFilter;
            $[77] = t47;
        } else {
            t47 = $[77];
        }
        let t48;
        if ($[78] === Symbol.for("react.memo_cache_sentinel")) {
            t48 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "px-3 py-2 rounded-lg bg-blue-600 text-white flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__["Filter"], {
                        size: 15
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 388,
                        columnNumber: 101
                    }, this),
                    " Filters"
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 388,
                columnNumber: 13
            }, this);
            $[78] = t48;
        } else {
            t48 = $[78];
        }
        let t49;
        if ($[79] !== t41 || $[80] !== t47) {
            t49 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3",
                children: [
                    t41,
                    t47,
                    t48
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 395,
                columnNumber: 13
            }, this);
            $[79] = t41;
            $[80] = t47;
            $[81] = t49;
        } else {
            t49 = $[81];
        }
        if ($[82] !== t36 || $[83] !== t49) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row items-center justify-between gap-4",
                children: [
                    t36,
                    t49
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 403,
                columnNumber: 13
            }, this);
            $[82] = t36;
            $[83] = t49;
            $[84] = t15;
        } else {
            t15 = $[84];
        }
        t11 = "border rounded-lg overflow-hidden";
        t8 = "min-w-full text-sm";
        if ($[85] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                className: "bg-slate-50 border-b",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-left",
                            children: "Date"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 413,
                            columnNumber: 56
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-left",
                            children: "Description"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 413,
                            columnNumber: 95
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-left",
                            children: "Category"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 413,
                            columnNumber: 141
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-left",
                            children: "Type"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 413,
                            columnNumber: 184
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-right",
                            children: "Amount"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 413,
                            columnNumber: 223
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                    lineNumber: 413,
                    columnNumber: 52
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 413,
                columnNumber: 12
            }, this);
            $[85] = t9;
        } else {
            t9 = $[85];
        }
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
            children: filtered.map(_OverviewPageFilteredMap)
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 418,
            columnNumber: 11
        }, this);
        t7 = "bg-slate-50 border-t font-semibold";
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
            className: "p-3",
            colSpan: 4,
            children: [
                "Total (",
                filtered.length,
                " items)"
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 420,
            columnNumber: 10
        }, this);
        t3 = "p-3 text-right";
        t4 = "\u20B9";
        t5 = filtered.reduce(_OverviewPageFilteredReduce, 0).toLocaleString();
        $[7] = categoryFilter;
        $[8] = groupOpen;
        $[9] = handleDetailed;
        $[10] = handleGroup;
        $[11] = handleKPI;
        $[12] = search;
        $[13] = typeFilter;
        $[14] = t10;
        $[15] = t11;
        $[16] = t12;
        $[17] = t13;
        $[18] = t14;
        $[19] = t15;
        $[20] = t3;
        $[21] = t4;
        $[22] = t5;
        $[23] = t6;
        $[24] = t7;
        $[25] = t8;
        $[26] = t9;
    } else {
        t10 = $[14];
        t11 = $[15];
        t12 = $[16];
        t13 = $[17];
        t14 = $[18];
        t15 = $[19];
        t3 = $[20];
        t4 = $[21];
        t5 = $[22];
        t6 = $[23];
        t7 = $[24];
        t8 = $[25];
        t9 = $[26];
    }
    let t16;
    if ($[86] !== t3 || $[87] !== t4 || $[88] !== t5) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
            className: t3,
            children: [
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 461,
            columnNumber: 11
        }, this);
        $[86] = t3;
        $[87] = t4;
        $[88] = t5;
        $[89] = t16;
    } else {
        t16 = $[89];
    }
    let t17;
    if ($[90] !== t16 || $[91] !== t6) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
            children: [
                t6,
                t16
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 471,
            columnNumber: 11
        }, this);
        $[90] = t16;
        $[91] = t6;
        $[92] = t17;
    } else {
        t17 = $[92];
    }
    let t18;
    if ($[93] !== t17 || $[94] !== t7) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tfoot", {
            className: t7,
            children: t17
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 480,
            columnNumber: 11
        }, this);
        $[93] = t17;
        $[94] = t7;
        $[95] = t18;
    } else {
        t18 = $[95];
    }
    let t19;
    if ($[96] !== t10 || $[97] !== t18 || $[98] !== t8 || $[99] !== t9) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
            className: t8,
            children: [
                t9,
                t10,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 489,
            columnNumber: 11
        }, this);
        $[96] = t10;
        $[97] = t18;
        $[98] = t8;
        $[99] = t9;
        $[100] = t19;
    } else {
        t19 = $[100];
    }
    let t20;
    if ($[101] !== t11 || $[102] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t11,
            children: t19
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 500,
            columnNumber: 11
        }, this);
        $[101] = t11;
        $[102] = t19;
        $[103] = t20;
    } else {
        t20 = $[103];
    }
    let t21;
    if ($[104] !== t12 || $[105] !== t13 || $[106] !== t14 || $[107] !== t15 || $[108] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t12,
            children: [
                t13,
                t14,
                t15,
                t20
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 509,
            columnNumber: 11
        }, this);
        $[104] = t12;
        $[105] = t13;
        $[106] = t14;
        $[107] = t15;
        $[108] = t20;
        $[109] = t21;
    } else {
        t21 = $[109];
    }
    return t21;
}
_s(OverviewPage, "h+WulgYIxQnt73CAPYW2M6OPX4w=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = OverviewPage;
function _OverviewPageFilteredReduce(s_1, x_1) {
    return s_1 + (x_1.type === "Expense" ? -x_1.amount : x_1.amount);
}
function _OverviewPageFilteredMap(t_4) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
        className: "border-b hover:bg-slate-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_4.date
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 525,
                columnNumber: 66
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_4.desc
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 525,
                columnNumber: 101
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_4.category
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 525,
                columnNumber: 136
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_4.type
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 525,
                columnNumber: 175
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: `p-3 text-right font-medium ${t_4.type === "Income" ? "text-emerald-600" : "text-rose-600"}`,
                children: [
                    t_4.type === "Expense" ? "-" : "+",
                    "₹",
                    t_4.amount
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 525,
                columnNumber: 210
            }, this)
        ]
    }, t_4.id, true, {
        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
        lineNumber: 525,
        columnNumber: 10
    }, this);
}
function _OverviewPageSampleCategoriesMap(c) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
        value: c.name,
        children: c.name
    }, c.id, false, {
        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
        lineNumber: 528,
        columnNumber: 10
    }, this);
}
function _OverviewPageAnonymous2(s_0, x_0) {
    return s_0 + x_0.amount;
}
function _OverviewPageSampleTransactionsFilter2(t_0) {
    return t_0.type === "Expense";
}
function _OverviewPageAnonymous(s, x) {
    return s + x.amount;
}
function _OverviewPageSampleTransactionsFilter(t) {
    return t.type === "Income";
}
var _c;
__turbopack_context__.k.register(_c, "OverviewPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_99b51d9b._.js.map