(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_recharts_es6_84d4f5ad._.js",
  "static/chunks/node_modules_edce8ebb._.js",
  "static/chunks/app_4cb6dfc7._.js"
],
    source: "dynamic"
});
