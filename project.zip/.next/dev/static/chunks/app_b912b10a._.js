(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/tools/finance/budget-ultimate/components/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function Card(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "f45420678617ef103bf58eb9594e9c8b398652b8c53bc0299d73a1d4de87218e") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f45420678617ef103bf58eb9594e9c8b398652b8c53bc0299d73a1d4de87218e";
    }
    const { children, className: t1 } = t0;
    const className = t1 === undefined ? "" : t1;
    const t2 = `bg-white border rounded-xl p-5 ${className}`;
    let t3;
    if ($[1] !== children || $[2] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t2,
            children: children
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Card.tsx",
            lineNumber: 18,
            columnNumber: 10
        }, this);
        $[1] = children;
        $[2] = t2;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    return t3;
}
_c = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/uid.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "uid",
    ()=>uid
]);
function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/utils/sampleData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sampleCategories",
    ()=>sampleCategories,
    "sampleTransactions",
    ()=>sampleTransactions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/uid.ts [app-client] (ecmascript)");
;
const sampleTransactions = [
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        date: "2025-01-05",
        type: "Expense",
        category: "Groceries",
        desc: "Milk, Bread",
        amount: 450,
        status: "Posted"
    },
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        date: "2025-01-10",
        type: "Income",
        category: "Salary",
        desc: "Monthly salary",
        amount: 48000,
        status: "Posted"
    }
];
const sampleCategories = [
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        name: "Groceries",
        type: "Expense",
        color: "#FF8A80"
    },
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        name: "Bills",
        type: "Expense",
        color: "#FFD180"
    },
    {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        name: "Salary",
        type: "Income",
        color: "#8CFF98"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// 
__turbopack_context__.s([
    "default",
    ()=>OverviewPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/utils/sampleData.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function OverviewPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(44);
    if ($[0] !== "e3047d7b71770fa59a84204f08a7b80c642870766e8ef011646c569397877239") {
        for(let $i = 0; $i < 44; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e3047d7b71770fa59a84204f08a7b80c642870766e8ef011646c569397877239";
    }
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let T0;
    let t0;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    if ($[1] !== search) {
        const totalIncome = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleTransactions"].filter(_OverviewPageSampleTransactionsFilter).reduce(_OverviewPageAnonymous, 0);
        const totalExpense = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleTransactions"].filter(_OverviewPageSampleTransactionsFilter2).reduce(_OverviewPageAnonymous2, 0);
        const balance = totalIncome - totalExpense;
        const recent = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleTransactions"].slice(-3).reverse();
        const last7Days = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleTransactions"].filter(_OverviewPageSampleTransactionsFilter3).slice(-7).reduce(_OverviewPageAnonymous3, 0);
        let t6;
        if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
            const map = {};
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleTransactions"].filter(_OverviewPageSampleTransactionsFilter4).forEach({
                "OverviewPage[(anonymous)()]": (t_3)=>map[t_3.category] = (map[t_3.category] || 0) + t_3.amount
            }["OverviewPage[(anonymous)()]"]);
            t6 = Object.entries(map).sort(_OverviewPageAnonymous4);
            $[9] = t6;
        } else {
            t6 = $[9];
        }
        const sorted = t6;
        const topCategory = sorted[0]?.[0] || "\u2014";
        let t7;
        if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
            t7 = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleTransactions"].filter(_OverviewPageSampleTransactionsFilter5);
            $[10] = t7;
        } else {
            t7 = $[10];
        }
        const txCount = t7.length;
        const avgDaily = Math.round(totalExpense / 30);
        t2 = "space-y-8 pb-6";
        let t8;
        if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-slate-500",
                children: "Income"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 56,
                columnNumber: 12
            }, this);
            $[11] = t8;
        } else {
            t8 = $[11];
        }
        let t9;
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "p-4",
                children: [
                    t8,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xl mt-1 font-bold text-emerald-600",
                        children: [
                            "₹",
                            totalIncome.toLocaleString()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 63,
                        columnNumber: 38
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 63,
                columnNumber: 12
            }, this);
            $[12] = t9;
        } else {
            t9 = $[12];
        }
        let t10;
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-slate-500",
                children: "Expense"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 70,
                columnNumber: 13
            }, this);
            $[13] = t10;
        } else {
            t10 = $[13];
        }
        let t11;
        if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
            t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "p-4",
                children: [
                    t10,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xl mt-1 font-bold text-rose-600",
                        children: [
                            "₹",
                            totalExpense.toLocaleString()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 77,
                        columnNumber: 40
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 77,
                columnNumber: 13
            }, this);
            $[14] = t11;
        } else {
            t11 = $[14];
        }
        let t12;
        if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-slate-500",
                children: "Balance"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 84,
                columnNumber: 13
            }, this);
            $[15] = t12;
        } else {
            t12 = $[15];
        }
        let t13;
        if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
            t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "p-4",
                children: [
                    t12,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xl mt-1 font-bold text-blue-600",
                        children: [
                            "₹",
                            balance.toLocaleString()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 91,
                        columnNumber: 40
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 91,
                columnNumber: 13
            }, this);
            $[16] = t13;
        } else {
            t13 = $[16];
        }
        if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 md:grid-cols-4 gap-4",
                children: [
                    t9,
                    t11,
                    t13,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        className: "p-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xs text-slate-500",
                                children: "Categories"
                            }, void 0, false, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                                lineNumber: 97,
                                columnNumber: 103
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xl mt-1 font-bold",
                                children: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleCategories"].length
                            }, void 0, false, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                                lineNumber: 97,
                                columnNumber: 159
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 97,
                        columnNumber: 81
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 97,
                columnNumber: 12
            }, this);
            $[17] = t3;
        } else {
            t3 = $[17];
        }
        let t14;
        if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-slate-500",
                children: "Last 7 Days Expense"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 104,
                columnNumber: 13
            }, this);
            $[18] = t14;
        } else {
            t14 = $[18];
        }
        let t15;
        if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "p-4",
                children: [
                    t14,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xl font-bold mt-1 text-rose-600",
                        children: [
                            "₹",
                            last7Days.toLocaleString()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 111,
                        columnNumber: 40
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 111,
                columnNumber: 13
            }, this);
            $[19] = t15;
        } else {
            t15 = $[19];
        }
        let t16;
        if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
            t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs text-slate-500",
                        children: "Top Category"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 118,
                        columnNumber: 35
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xl font-bold mt-1",
                        children: topCategory
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 118,
                        columnNumber: 93
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 118,
                columnNumber: 13
            }, this);
            $[20] = t16;
        } else {
            t16 = $[20];
        }
        let t17;
        if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs text-slate-500",
                        children: "Transactions (This Month)"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 125,
                        columnNumber: 35
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xl font-bold mt-1",
                        children: txCount
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 125,
                        columnNumber: 106
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 125,
                columnNumber: 13
            }, this);
            $[21] = t17;
        } else {
            t17 = $[21];
        }
        let t18;
        if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
            t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-slate-500",
                children: "Avg Daily Spend"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 132,
                columnNumber: 13
            }, this);
            $[22] = t18;
        } else {
            t18 = $[22];
        }
        if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 md:grid-cols-4 gap-4",
                children: [
                    t15,
                    t16,
                    t17,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        className: "p-4",
                        children: [
                            t18,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-xl font-bold mt-1 text-rose-600",
                                children: [
                                    "₹",
                                    avgDaily.toLocaleString()
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                                lineNumber: 138,
                                columnNumber: 109
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 138,
                        columnNumber: 82
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 138,
                columnNumber: 12
            }, this);
            $[23] = t4;
        } else {
            t4 = $[23];
        }
        let t19;
        if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                size: 16,
                className: "absolute left-3 top-2.5 text-slate-400"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 145,
                columnNumber: 13
            }, this);
            $[24] = t19;
        } else {
            t19 = $[24];
        }
        let t20;
        if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
            t20 = ({
                "OverviewPage[<input>.onChange]": (e)=>setSearch(e.target.value)
            })["OverviewPage[<input>.onChange]"];
            $[25] = t20;
        } else {
            t20 = $[25];
        }
        const t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            className: "w-full pl-10 pr-3 py-2 border rounded-lg text-sm",
            placeholder: "Search transactions...",
            value: search,
            onChange: t20
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 159,
            columnNumber: 17
        }, this);
        let t22;
        if ($[26] !== t21) {
            t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    t19,
                    t21
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 162,
                columnNumber: 13
            }, this);
            $[26] = t21;
            $[27] = t22;
        } else {
            t22 = $[27];
        }
        let t23;
        if ($[28] === Symbol.for("react.memo_cache_sentinel")) {
            t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                className: "border px-3 py-2 rounded-lg text-sm w-full",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        children: "All Categories"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 170,
                        columnNumber: 76
                    }, this),
                    __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sampleCategories"].map(_OverviewPageSampleCategoriesMap)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 170,
                columnNumber: 13
            }, this);
            $[28] = t23;
        } else {
            t23 = $[28];
        }
        let t24;
        if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
            t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                className: "border px-3 py-2 rounded-lg text-sm w-full",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        children: "All Types"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 177,
                        columnNumber: 76
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        children: "Income"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 177,
                        columnNumber: 102
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                        children: "Expense"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 177,
                        columnNumber: 125
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 177,
                columnNumber: 13
            }, this);
            $[29] = t24;
        } else {
            t24 = $[29];
        }
        if ($[30] !== t22) {
            t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "p-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-3 gap-3",
                    children: [
                        t22,
                        t23,
                        t24
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                    lineNumber: 183,
                    columnNumber: 34
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 183,
                columnNumber: 12
            }, this);
            $[30] = t22;
            $[31] = t5;
        } else {
            t5 = $[31];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
            t0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-4 border-b font-semibold text-sm",
                children: "Recent Transactions"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 191,
                columnNumber: 12
            }, this);
            $[32] = t0;
        } else {
            t0 = $[32];
        }
        t1 = recent.map(_OverviewPageRecentMap);
        $[1] = search;
        $[2] = T0;
        $[3] = t0;
        $[4] = t1;
        $[5] = t2;
        $[6] = t3;
        $[7] = t4;
        $[8] = t5;
    } else {
        T0 = $[2];
        t0 = $[3];
        t1 = $[4];
        t2 = $[5];
        t3 = $[6];
        t4 = $[7];
        t5 = $[8];
    }
    let t6;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-3 text-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: "/tools/finance/budget-ultimate/transactions",
                className: "text-blue-600 underline text-sm",
                children: "View Full Transactions →"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 216,
                columnNumber: 43
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 216,
            columnNumber: 10
        }, this);
        $[33] = t6;
    } else {
        t6 = $[33];
    }
    let t7;
    if ($[34] !== T0 || $[35] !== t0 || $[36] !== t1) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            children: [
                t0,
                t1,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 223,
            columnNumber: 10
        }, this);
        $[34] = T0;
        $[35] = t0;
        $[36] = t1;
        $[37] = t7;
    } else {
        t7 = $[37];
    }
    let t8;
    if ($[38] !== t2 || $[39] !== t3 || $[40] !== t4 || $[41] !== t5 || $[42] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t2,
            children: [
                t3,
                t4,
                t5,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 233,
            columnNumber: 10
        }, this);
        $[38] = t2;
        $[39] = t3;
        $[40] = t4;
        $[41] = t5;
        $[42] = t7;
        $[43] = t8;
    } else {
        t8 = $[43];
    }
    return t8;
}
_s(OverviewPage, "42GASUL8pX2/N6Oh5HTh0GvQEF0=");
_c = OverviewPage;
function _OverviewPageRecentMap(t_5) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "px-4 py-3 border-b flex justify-between",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "font-medium",
                        children: t_5.desc
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 246,
                        columnNumber: 85
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-xs text-slate-500",
                        children: t_5.date
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 246,
                        columnNumber: 130
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 246,
                columnNumber: 80
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `font-semibold ${t_5.type === "Income" ? "text-emerald-600" : "text-rose-600"}`,
                children: [
                    t_5.type === "Expense" ? "-" : "+",
                    "₹",
                    t_5.amount
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 246,
                columnNumber: 192
            }, this)
        ]
    }, t_5.id, true, {
        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
        lineNumber: 246,
        columnNumber: 10
    }, this);
}
function _OverviewPageSampleCategoriesMap(c) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
        children: c.name
    }, c.id, false, {
        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
        lineNumber: 249,
        columnNumber: 10
    }, this);
}
function _OverviewPageSampleTransactionsFilter5(t_4) {
    return t_4.date.startsWith("2025-01");
}
function _OverviewPageAnonymous4(a, b) {
    return b[1] - a[1];
}
function _OverviewPageSampleTransactionsFilter4(t_2) {
    return t_2.type === "Expense";
}
function _OverviewPageAnonymous3(s_1, x_1) {
    return s_1 + x_1.amount;
}
function _OverviewPageSampleTransactionsFilter3(t_1) {
    return t_1.type === "Expense";
}
function _OverviewPageAnonymous2(s_0, x_0) {
    return s_0 + x_0.amount;
}
function _OverviewPageSampleTransactionsFilter2(t_0) {
    return t_0.type === "Expense";
}
function _OverviewPageAnonymous(s, x) {
    return s + x.amount;
}
function _OverviewPageSampleTransactionsFilter(t) {
    return t.type === "Income";
}
var _c;
__turbopack_context__.k.register(_c, "OverviewPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_b912b10a._.js.map