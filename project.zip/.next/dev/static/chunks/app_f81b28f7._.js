(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/utils/uid.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Simple uid generator used across the app.
 * Deterministic enough for demo / local usage.
 */ __turbopack_context__.s([
    "uid",
    ()=>uid
]);
function uid(prefix = "") {
    // timestamp + random base36 suffix
    return prefix + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 9);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/storage.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LS_KEYS",
    ()=>LS_KEYS,
    "readLS",
    ()=>readLS,
    "writeLS",
    ()=>writeLS
]);
const LS_KEYS = {
    TRANSACTIONS: "ots_budget_txns_v2",
    CATEGORIES: "ots_budget_categories_v1",
    VARIANTS: "ots_budget_variants_v1",
    SETTINGS: "ots_budget_settings_v1"
};
function readLS(key, fallback = null) {
    try {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
        return fallback;
    }
}
function writeLS(key, value) {
    try {
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
    // noop
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/utils/sampleData.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addCategory",
    ()=>addCategory,
    "addTransaction",
    ()=>addTransaction,
    "clearTransactions",
    ()=>clearTransactions,
    "getCategories",
    ()=>getCategories,
    "getTransactions",
    ()=>getTransactions,
    "saveTransactions",
    ()=>saveTransactions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/uid.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/storage.ts [app-client] (ecmascript)");
;
;
;
function getTransactions() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].TRANSACTIONS, []);
}
function saveTransactions(list) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["writeLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].TRANSACTIONS, list);
}
function addTransaction(txn) {
    const all = getTransactions();
    const newTxn = {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        ...txn
    };
    const updated = [
        ...all,
        newTxn
    ];
    saveTransactions(updated);
    return newTxn;
}
function clearTransactions() {
    saveTransactions([]);
}
function getCategories() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].CATEGORIES, []);
}
function addCategory(name, type) {
    const all = getCategories();
    const newCat = {
        id: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$uid$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uid"])(),
        name,
        type
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["writeLS"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$storage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LS_KEYS"].CATEGORIES, [
        ...all,
        newCat
    ]);
    return newCat;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AnalyticTile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$LineChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/chart/LineChart.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/cartesian/Line.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/component/ResponsiveContainer.js [app-client] (ecmascript)");
"use client";
;
;
;
function AnalyticTile(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "8a42b6150661b25d75e91c0f443ccb2abca94fc85fd04e1f3cd912a986b4c8f5") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8a42b6150661b25d75e91c0f443ccb2abca94fc85fd04e1f3cd912a986b4c8f5";
    }
    const { title, value, colorClass: t1, trendText: t2, data: t3, onClick } = t0;
    const colorClass = t1 === undefined ? "" : t1;
    const trendText = t2 === undefined ? "" : t2;
    let t4;
    if ($[1] !== t3) {
        t4 = t3 === undefined ? [] : t3;
        $[1] = t3;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    const data = t4;
    let t5;
    if ($[3] !== title) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-xs text-slate-500",
            children: title
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 46,
            columnNumber: 10
        }, this);
        $[3] = title;
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    const t6 = `text-2xl font-bold mt-1 ${colorClass}`;
    let t7;
    if ($[5] !== t6 || $[6] !== value) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t6,
            children: value
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 55,
            columnNumber: 10
        }, this);
        $[5] = t6;
        $[6] = value;
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    let t8;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Line"], {
            type: "monotone",
            dataKey: "amt",
            stroke: "currentColor",
            strokeWidth: 2,
            dot: false
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 64,
            columnNumber: 10
        }, this);
        $[8] = t8;
    } else {
        t8 = $[8];
    }
    let t9;
    if ($[9] !== data) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-10 mt-2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResponsiveContainer"], {
                width: "100%",
                height: "100%",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$LineChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineChart"], {
                    data: data,
                    children: t8
                }, void 0, false, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
                    lineNumber: 71,
                    columnNumber: 85
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
                lineNumber: 71,
                columnNumber: 37
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[9] = data;
        $[10] = t9;
    } else {
        t9 = $[10];
    }
    let t10;
    if ($[11] !== trendText) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-xs text-slate-500 mt-1",
            children: trendText
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 79,
            columnNumber: 11
        }, this);
        $[11] = trendText;
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    let t11;
    if ($[13] !== onClick || $[14] !== t10 || $[15] !== t5 || $[16] !== t7 || $[17] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            onClick: onClick,
            className: "p-4 border rounded-lg bg-white hover:shadow-md transition cursor-pointer",
            children: [
                t5,
                t7,
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 87,
            columnNumber: 11
        }, this);
        $[13] = onClick;
        $[14] = t10;
        $[15] = t5;
        $[16] = t7;
        $[17] = t9;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    return t11;
}
_c = AnalyticTile;
var _c;
__turbopack_context__.k.register(_c, "AnalyticTile");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OverviewPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/utils/sampleData.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/funnel.js [app-client] (ecmascript) <export default as Filter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chart-column.js [app-client] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$panel$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutPanelLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layout-panel-left.js [app-client] (ecmascript) <export default as LayoutPanelLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function OverviewPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(83);
    if ($[0] !== "12cc9f8467cf2c47da14b85a4a1ad662c1d8335e8ca072a504f3cacc997ce6a5") {
        for(let $i = 0; $i < 83; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "12cc9f8467cf2c47da14b85a4a1ad662c1d8335e8ca072a504f3cacc997ce6a5";
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [txns, setTxns] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [, setCats] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    let t2;
    let t3;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "OverviewPage[useEffect()]": ()=>{
                setTxns((0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTransactions"])());
                setCats((0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleData$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCategories"])());
            }
        })["OverviewPage[useEffect()]"];
        t3 = [];
        $[3] = t2;
        $[4] = t3;
    } else {
        t2 = $[3];
        t3 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    let T0;
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t16;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[5] !== search || $[6] !== txns) {
        const income = txns.filter(_OverviewPageTxnsFilter).reduce(_OverviewPageAnonymous, 0);
        const expense = txns.filter(_OverviewPageTxnsFilter2).reduce(_OverviewPageAnonymous2, 0);
        const balance = income - expense;
        let t17;
        if ($[21] !== search) {
            t17 = ({
                "OverviewPage[txns.filter()]": (t_1)=>t_1.desc.toLowerCase().includes(search.toLowerCase())
            })["OverviewPage[txns.filter()]"];
            $[21] = search;
            $[22] = t17;
        } else {
            t17 = $[22];
        }
        const filtered = txns.filter(t17);
        t13 = "space-y-8";
        const t18 = `₹${income.toLocaleString()}`;
        let t19;
        if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = [
                {
                    amt: 2000
                },
                {
                    amt: 3500
                },
                {
                    amt: 5000
                }
            ];
            $[23] = t19;
        } else {
            t19 = $[23];
        }
        let t20;
        if ($[24] !== t18) {
            t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Income",
                value: t18,
                colorClass: "text-emerald-600",
                trendText: "+12% vs last month",
                data: t19
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 98,
                columnNumber: 13
            }, this);
            $[24] = t18;
            $[25] = t20;
        } else {
            t20 = $[25];
        }
        const t21 = `₹${expense.toLocaleString()}`;
        let t22;
        if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
            t22 = [
                {
                    amt: 400
                },
                {
                    amt: 500
                },
                {
                    amt: 350
                }
            ];
            $[26] = t22;
        } else {
            t22 = $[26];
        }
        let t23;
        if ($[27] !== t21) {
            t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Expense",
                value: t21,
                colorClass: "text-rose-600",
                trendText: "-5% variance",
                data: t22
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 120,
                columnNumber: 13
            }, this);
            $[27] = t21;
            $[28] = t23;
        } else {
            t23 = $[28];
        }
        let t24;
        if ($[29] !== balance) {
            t24 = balance.toLocaleString();
            $[29] = balance;
            $[30] = t24;
        } else {
            t24 = $[30];
        }
        const t25 = `₹${t24}`;
        const t26 = balance - 2000;
        let t27;
        if ($[31] !== t26) {
            t27 = {
                amt: t26
            };
            $[31] = t26;
            $[32] = t27;
        } else {
            t27 = $[32];
        }
        let t28;
        if ($[33] !== balance) {
            t28 = {
                amt: balance
            };
            $[33] = balance;
            $[34] = t28;
        } else {
            t28 = $[34];
        }
        let t29;
        if ($[35] !== t27 || $[36] !== t28) {
            t29 = [
                t27,
                t28
            ];
            $[35] = t27;
            $[36] = t28;
            $[37] = t29;
        } else {
            t29 = $[37];
        }
        let t30;
        if ($[38] !== t25 || $[39] !== t29) {
            t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Balance",
                value: t25,
                colorClass: "text-blue-600",
                trendText: "Stable",
                data: t29
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 167,
                columnNumber: 13
            }, this);
            $[38] = t25;
            $[39] = t29;
            $[40] = t30;
        } else {
            t30 = $[40];
        }
        let t31;
        if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
            t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Categories",
                value: categories.length,
                colorClass: "text-slate-900",
                trendText: "Active groups",
                data: [
                    {
                        amt: 2
                    },
                    {
                        amt: 3
                    },
                    {
                        amt: 5
                    }
                ]
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 176,
                columnNumber: 13
            }, this);
            $[41] = t31;
        } else {
            t31 = $[41];
        }
        let t32;
        if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
            t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                title: "Savings Rate",
                value: `${savingsRate}%`,
                colorClass: "text-indigo-600",
                trendText: "Income saved",
                data: [
                    {
                        amt: 5
                    },
                    {
                        amt: 10
                    },
                    {
                        amt: 12
                    }
                ]
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 189,
                columnNumber: 13
            }, this);
            $[42] = t32;
        } else {
            t32 = $[42];
        }
        if ($[43] !== t20 || $[44] !== t23 || $[45] !== t30) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-2 md:grid-cols-5 gap-4",
                children: [
                    t20,
                    t23,
                    t30,
                    t31,
                    t32
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 201,
                columnNumber: 13
            }, this);
            $[43] = t20;
            $[44] = t23;
            $[45] = t30;
            $[46] = t14;
        } else {
            t14 = $[46];
        }
        let t33;
        if ($[47] === Symbol.for("react.memo_cache_sentinel")) {
            t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-lg font-semibold",
                children: "Transactions"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 211,
                columnNumber: 13
            }, this);
            $[47] = t33;
        } else {
            t33 = $[47];
        }
        let t34;
        if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
            t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "px-3 py-2 border rounded-lg flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"], {
                        size: 16
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 218,
                        columnNumber: 85
                    }, this),
                    " KPI Dashboard"
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 218,
                columnNumber: 13
            }, this);
            $[48] = t34;
        } else {
            t34 = $[48];
        }
        if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    t33,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 text-sm",
                        children: [
                            t34,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "px-3 py-2 border rounded-lg flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$panel$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutPanelLeft$3e$__["LayoutPanelLeft"], {
                                        size: 16
                                    }, void 0, false, {
                                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                                        lineNumber: 224,
                                        columnNumber: 182
                                    }, this),
                                    " Detailed Analytics"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                                lineNumber: 224,
                                columnNumber: 110
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "px-3 py-2 border rounded-lg",
                                children: "Group by…"
                            }, void 0, false, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                                lineNumber: 224,
                                columnNumber: 239
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 224,
                        columnNumber: 69
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 224,
                columnNumber: 13
            }, this);
            $[49] = t15;
        } else {
            t15 = $[49];
        }
        let t35;
        if ($[50] === Symbol.for("react.memo_cache_sentinel")) {
            t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                size: 16,
                className: "absolute left-3 top-2.5 text-slate-400"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 231,
                columnNumber: 13
            }, this);
            $[50] = t35;
        } else {
            t35 = $[50];
        }
        let t36;
        if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
            t36 = ({
                "OverviewPage[<input>.onChange]": (e)=>setSearch(e.target.value)
            })["OverviewPage[<input>.onChange]"];
            $[51] = t36;
        } else {
            t36 = $[51];
        }
        let t37;
        if ($[52] !== search) {
            t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-72",
                children: [
                    t35,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        className: "pl-10 pr-3 py-2 border rounded-lg w-full",
                        placeholder: "Search\u2026",
                        value: search,
                        onChange: t36
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 247,
                        columnNumber: 49
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 247,
                columnNumber: 13
            }, this);
            $[52] = search;
            $[53] = t37;
        } else {
            t37 = $[53];
        }
        let t38;
        if ($[54] === Symbol.for("react.memo_cache_sentinel")) {
            t38 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "px-3 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__["Filter"], {
                        size: 15
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 255,
                        columnNumber: 101
                    }, this),
                    " Filters"
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 255,
                columnNumber: 13
            }, this);
            $[54] = t38;
        } else {
            t38 = $[54];
        }
        if ($[55] !== t37) {
            t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between gap-4",
                children: [
                    t37,
                    t38
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 261,
                columnNumber: 13
            }, this);
            $[55] = t37;
            $[56] = t16;
        } else {
            t16 = $[56];
        }
        T0 = Card;
        t12 = "p-0";
        t9 = "min-w-full text-sm";
        if ($[57] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                className: "bg-slate-50 border-b",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-left",
                            children: "Date"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 271,
                            columnNumber: 57
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-left",
                            children: "Description"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 271,
                            columnNumber: 96
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-left",
                            children: "Category"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 271,
                            columnNumber: 142
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-right",
                            children: "Amount"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 271,
                            columnNumber: 185
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                    lineNumber: 271,
                    columnNumber: 53
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 271,
                columnNumber: 13
            }, this);
            $[57] = t10;
        } else {
            t10 = $[57];
        }
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
            children: filtered.map(_OverviewPageFilteredMap)
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 276,
            columnNumber: 11
        }, this);
        t8 = "bg-slate-50 border-t font-semibold";
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
            className: "p-3",
            colSpan: 3,
            children: [
                "Total (",
                filtered.length,
                " items)"
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 278,
            columnNumber: 10
        }, this);
        t4 = "p-3 text-right";
        t5 = "\u20B9";
        t6 = filtered.reduce(_OverviewPageFilteredReduce, 0).toLocaleString();
        $[5] = search;
        $[6] = txns;
        $[7] = T0;
        $[8] = t10;
        $[9] = t11;
        $[10] = t12;
        $[11] = t13;
        $[12] = t14;
        $[13] = t15;
        $[14] = t16;
        $[15] = t4;
        $[16] = t5;
        $[17] = t6;
        $[18] = t7;
        $[19] = t8;
        $[20] = t9;
    } else {
        T0 = $[7];
        t10 = $[8];
        t11 = $[9];
        t12 = $[10];
        t13 = $[11];
        t14 = $[12];
        t15 = $[13];
        t16 = $[14];
        t4 = $[15];
        t5 = $[16];
        t6 = $[17];
        t7 = $[18];
        t8 = $[19];
        t9 = $[20];
    }
    let t17;
    if ($[58] !== t4 || $[59] !== t5 || $[60] !== t6) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
            className: t4,
            children: [
                t5,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 316,
            columnNumber: 11
        }, this);
        $[58] = t4;
        $[59] = t5;
        $[60] = t6;
        $[61] = t17;
    } else {
        t17 = $[61];
    }
    let t18;
    if ($[62] !== t17 || $[63] !== t7) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
            children: [
                t7,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 326,
            columnNumber: 11
        }, this);
        $[62] = t17;
        $[63] = t7;
        $[64] = t18;
    } else {
        t18 = $[64];
    }
    let t19;
    if ($[65] !== t18 || $[66] !== t8) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tfoot", {
            className: t8,
            children: t18
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 335,
            columnNumber: 11
        }, this);
        $[65] = t18;
        $[66] = t8;
        $[67] = t19;
    } else {
        t19 = $[67];
    }
    let t20;
    if ($[68] !== t10 || $[69] !== t11 || $[70] !== t19 || $[71] !== t9) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
            className: t9,
            children: [
                t10,
                t11,
                t19
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 344,
            columnNumber: 11
        }, this);
        $[68] = t10;
        $[69] = t11;
        $[70] = t19;
        $[71] = t9;
        $[72] = t20;
    } else {
        t20 = $[72];
    }
    let t21;
    if ($[73] !== T0 || $[74] !== t12 || $[75] !== t20) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            className: t12,
            children: t20
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 355,
            columnNumber: 11
        }, this);
        $[73] = T0;
        $[74] = t12;
        $[75] = t20;
        $[76] = t21;
    } else {
        t21 = $[76];
    }
    let t22;
    if ($[77] !== t13 || $[78] !== t14 || $[79] !== t15 || $[80] !== t16 || $[81] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t13,
            children: [
                t14,
                t15,
                t16,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 365,
            columnNumber: 11
        }, this);
        $[77] = t13;
        $[78] = t14;
        $[79] = t15;
        $[80] = t16;
        $[81] = t21;
        $[82] = t22;
    } else {
        t22 = $[82];
    }
    return t22;
}
_s(OverviewPage, "m0SXTDlBq38GG+IdNtnUG/4v0kY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = OverviewPage;
function _OverviewPageFilteredReduce(s_1, x_1) {
    return s_1 + (x_1.type === "Expense" ? -x_1.amount : x_1.amount);
}
function _OverviewPageFilteredMap(t_2) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
        className: "border-b hover:bg-slate-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_2.date
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 381,
                columnNumber: 66
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_2.desc
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 381,
                columnNumber: 101
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_2.category
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 381,
                columnNumber: 136
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: `p-3 text-right font-medium ${t_2.type === "Income" ? "text-emerald-600" : "text-rose-600"}`,
                children: [
                    t_2.type === "Expense" ? "-" : "+",
                    "₹",
                    t_2.amount
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 381,
                columnNumber: 175
            }, this)
        ]
    }, t_2.id, true, {
        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
        lineNumber: 381,
        columnNumber: 10
    }, this);
}
function _OverviewPageAnonymous2(s_0, x_0) {
    return s_0 + x_0.amount;
}
function _OverviewPageTxnsFilter2(t_0) {
    return t_0.type === "Expense";
}
function _OverviewPageAnonymous(s, x) {
    return s + x.amount;
}
function _OverviewPageTxnsFilter(t) {
    return t.type === "Income";
}
var _c;
__turbopack_context__.k.register(_c, "OverviewPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_f81b28f7._.js.map