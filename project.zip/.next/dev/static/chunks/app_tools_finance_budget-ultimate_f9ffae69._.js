(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/tools/finance/budget-ultimate/components/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function Card(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "f45420678617ef103bf58eb9594e9c8b398652b8c53bc0299d73a1d4de87218e") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f45420678617ef103bf58eb9594e9c8b398652b8c53bc0299d73a1d4de87218e";
    }
    const { children, className: t1 } = t0;
    const className = t1 === undefined ? "" : t1;
    const t2 = `bg-white border rounded-xl p-5 ${className}`;
    let t3;
    if ($[1] !== children || $[2] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t2,
            children: children
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Card.tsx",
            lineNumber: 18,
            columnNumber: 10
        }, this);
        $[1] = children;
        $[2] = t2;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    return t3;
}
_c = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AnalyticTile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$LineChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/chart/LineChart.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/cartesian/Line.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/recharts/es6/component/ResponsiveContainer.js [app-client] (ecmascript)");
"use client";
;
;
;
function AnalyticTile(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "8a42b6150661b25d75e91c0f443ccb2abca94fc85fd04e1f3cd912a986b4c8f5") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8a42b6150661b25d75e91c0f443ccb2abca94fc85fd04e1f3cd912a986b4c8f5";
    }
    const { title, value, colorClass: t1, trendText: t2, data: t3, onClick } = t0;
    const colorClass = t1 === undefined ? "" : t1;
    const trendText = t2 === undefined ? "" : t2;
    let t4;
    if ($[1] !== t3) {
        t4 = t3 === undefined ? [] : t3;
        $[1] = t3;
        $[2] = t4;
    } else {
        t4 = $[2];
    }
    const data = t4;
    let t5;
    if ($[3] !== title) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-xs text-slate-500",
            children: title
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 46,
            columnNumber: 10
        }, this);
        $[3] = title;
        $[4] = t5;
    } else {
        t5 = $[4];
    }
    const t6 = `text-2xl font-bold mt-1 ${colorClass}`;
    let t7;
    if ($[5] !== t6 || $[6] !== value) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t6,
            children: value
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 55,
            columnNumber: 10
        }, this);
        $[5] = t6;
        $[6] = value;
        $[7] = t7;
    } else {
        t7 = $[7];
    }
    let t8;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$cartesian$2f$Line$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Line"], {
            type: "monotone",
            dataKey: "amt",
            stroke: "currentColor",
            strokeWidth: 2,
            dot: false
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 64,
            columnNumber: 10
        }, this);
        $[8] = t8;
    } else {
        t8 = $[8];
    }
    let t9;
    if ($[9] !== data) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-10 mt-2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$component$2f$ResponsiveContainer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ResponsiveContainer"], {
                width: "100%",
                height: "100%",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$recharts$2f$es6$2f$chart$2f$LineChart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LineChart"], {
                    data: data,
                    children: t8
                }, void 0, false, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
                    lineNumber: 71,
                    columnNumber: 85
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
                lineNumber: 71,
                columnNumber: 37
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 71,
            columnNumber: 10
        }, this);
        $[9] = data;
        $[10] = t9;
    } else {
        t9 = $[10];
    }
    let t10;
    if ($[11] !== trendText) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-xs text-slate-500 mt-1",
            children: trendText
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 79,
            columnNumber: 11
        }, this);
        $[11] = trendText;
        $[12] = t10;
    } else {
        t10 = $[12];
    }
    let t11;
    if ($[13] !== onClick || $[14] !== t10 || $[15] !== t5 || $[16] !== t7 || $[17] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            onClick: onClick,
            className: "p-4 border rounded-lg bg-white hover:shadow-md transition cursor-pointer",
            children: [
                t5,
                t7,
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx",
            lineNumber: 87,
            columnNumber: 11
        }, this);
        $[13] = onClick;
        $[14] = t10;
        $[15] = t5;
        $[16] = t7;
        $[17] = t9;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    return t11;
}
_c = AnalyticTile;
var _c;
__turbopack_context__.k.register(_c, "AnalyticTile");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OverviewPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/components/Card.tsx [app-client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../utils/sampleData'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/funnel.js [app-client] (ecmascript) <export default as Filter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chart-column.js [app-client] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$panel$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutPanelLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/layout-panel-left.js [app-client] (ecmascript) <export default as LayoutPanelLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/components/AnalyticTile.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function OverviewPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(44);
    if ($[0] !== "06b3031989c23c579d11c8bbf685417fb885c2ec5f94319bdf82ac5c472e4c4e") {
        for(let $i = 0; $i < 44; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "06b3031989c23c579d11c8bbf685417fb885c2ec5f94319bdf82ac5c472e4c4e";
    }
    const transactions = loadTransactions();
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = loadCategories();
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const categories = t0;
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const income = transactions.filter(_OverviewPageTransactionsFilter).reduce(_OverviewPageAnonymous, 0);
    const expense = transactions.filter(_OverviewPageTransactionsFilter2).reduce(_OverviewPageAnonymous2, 0);
    const balance = income - expense;
    const savingsRate = income > 0 ? (balance / income * 100).toFixed(1) : "0";
    let t1;
    if ($[2] !== search) {
        t1 = ({
            "OverviewPage[transactions.filter()]": (t_1)=>t_1.desc.toLowerCase().includes(search.toLowerCase())
        })["OverviewPage[transactions.filter()]"];
        $[2] = search;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const filtered = transactions.filter(t1);
    const t2 = `₹${income.toLocaleString()}`;
    let t3;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [
            {
                amt: 2000
            },
            {
                amt: 3500
            },
            {
                amt: 5000
            }
        ];
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    let t4;
    if ($[5] !== t2) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: "Income",
            value: t2,
            colorClass: "text-emerald-600",
            trendText: "+12% vs last month",
            data: t3
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 58,
            columnNumber: 10
        }, this);
        $[5] = t2;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const t5 = `₹${expense.toLocaleString()}`;
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = [
            {
                amt: 400
            },
            {
                amt: 500
            },
            {
                amt: 350
            }
        ];
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] !== t5) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: "Expense",
            value: t5,
            colorClass: "text-rose-600",
            trendText: "-5% variance",
            data: t6
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[8] = t5;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== balance) {
        t8 = balance.toLocaleString();
        $[10] = balance;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    const t9 = `₹${t8}`;
    const t10 = balance - 2000;
    let t11;
    if ($[12] !== t10) {
        t11 = {
            amt: t10
        };
        $[12] = t10;
        $[13] = t11;
    } else {
        t11 = $[13];
    }
    let t12;
    if ($[14] !== balance) {
        t12 = {
            amt: balance
        };
        $[14] = balance;
        $[15] = t12;
    } else {
        t12 = $[15];
    }
    let t13;
    if ($[16] !== t11 || $[17] !== t12) {
        t13 = [
            t11,
            t12
        ];
        $[16] = t11;
        $[17] = t12;
        $[18] = t13;
    } else {
        t13 = $[18];
    }
    let t14;
    if ($[19] !== t13 || $[20] !== t9) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: "Balance",
            value: t9,
            colorClass: "text-blue-600",
            trendText: "Stable",
            data: t13
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 127,
            columnNumber: 11
        }, this);
        $[19] = t13;
        $[20] = t9;
        $[21] = t14;
    } else {
        t14 = $[21];
    }
    let t15;
    if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: "Categories",
            value: categories.length,
            colorClass: "text-slate-900",
            trendText: "Active groups",
            data: [
                {
                    amt: 2
                },
                {
                    amt: 3
                },
                {
                    amt: 5
                }
            ]
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 136,
            columnNumber: 11
        }, this);
        $[22] = t15;
    } else {
        t15 = $[22];
    }
    const t16 = `${savingsRate}%`;
    let t17;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = [
            {
                amt: 5
            },
            {
                amt: 10
            },
            {
                amt: 12
            }
        ];
        $[23] = t17;
    } else {
        t17 = $[23];
    }
    let t18;
    if ($[24] !== t16) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$AnalyticTile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            title: "Savings Rate",
            value: t16,
            colorClass: "text-indigo-600",
            trendText: "Income saved",
            data: t17
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 163,
            columnNumber: 11
        }, this);
        $[24] = t16;
        $[25] = t18;
    } else {
        t18 = $[25];
    }
    let t19;
    if ($[26] !== t14 || $[27] !== t18 || $[28] !== t4 || $[29] !== t7) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-2 md:grid-cols-5 gap-4",
            children: [
                t4,
                t7,
                t14,
                t15,
                t18
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 171,
            columnNumber: 11
        }, this);
        $[26] = t14;
        $[27] = t18;
        $[28] = t4;
        $[29] = t7;
        $[30] = t19;
    } else {
        t19 = $[30];
    }
    let t20;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-lg font-semibold",
            children: "Transactions"
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 182,
            columnNumber: 11
        }, this);
        $[31] = t20;
    } else {
        t20 = $[31];
    }
    let t21;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "px-3 py-2 border rounded-lg flex items-center gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"], {
                    size: 16
                }, void 0, false, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                    lineNumber: 189,
                    columnNumber: 83
                }, this),
                " KPI Dashboard"
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 189,
            columnNumber: 11
        }, this);
        $[32] = t21;
    } else {
        t21 = $[32];
    }
    let t22;
    if ($[33] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-between",
            children: [
                t20,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3 text-sm",
                    children: [
                        t21,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "px-3 py-2 border rounded-lg flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$layout$2d$panel$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LayoutPanelLeft$3e$__["LayoutPanelLeft"], {
                                    size: 16
                                }, void 0, false, {
                                    fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                                    lineNumber: 196,
                                    columnNumber: 180
                                }, this),
                                " Detailed Analytics"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 196,
                            columnNumber: 108
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "px-3 py-2 border rounded-lg",
                            children: "Group by…"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 196,
                            columnNumber: 237
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                    lineNumber: 196,
                    columnNumber: 67
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 196,
            columnNumber: 11
        }, this);
        $[33] = t22;
    } else {
        t22 = $[33];
    }
    let t23;
    if ($[34] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
            size: 16,
            className: "absolute left-3 top-2.5 text-slate-400"
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 203,
            columnNumber: 11
        }, this);
        $[34] = t23;
    } else {
        t23 = $[34];
    }
    let t24;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = ({
            "OverviewPage[<input>.onChange]": (e)=>setSearch(e.target.value)
        })["OverviewPage[<input>.onChange]"];
        $[35] = t24;
    } else {
        t24 = $[35];
    }
    let t25;
    if ($[36] !== search) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative w-72",
            children: [
                t23,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    className: "pl-10 pr-3 py-2 border rounded-lg w-full",
                    placeholder: "Search\u2026",
                    value: search,
                    onChange: t24
                }, void 0, false, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                    lineNumber: 219,
                    columnNumber: 47
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 219,
            columnNumber: 11
        }, this);
        $[36] = search;
        $[37] = t25;
    } else {
        t25 = $[37];
    }
    let t26;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "px-3 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$funnel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Filter$3e$__["Filter"], {
                    size: 15
                }, void 0, false, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                    lineNumber: 227,
                    columnNumber: 99
                }, this),
                " Filters"
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 227,
            columnNumber: 11
        }, this);
        $[38] = t26;
    } else {
        t26 = $[38];
    }
    let t27;
    if ($[39] !== t25) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-between gap-4",
            children: [
                t25,
                t26
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 234,
            columnNumber: 11
        }, this);
        $[39] = t25;
        $[40] = t27;
    } else {
        t27 = $[40];
    }
    let t28;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
            className: "bg-slate-50 border-b",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                        className: "p-3 text-left",
                        children: "Date"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 242,
                        columnNumber: 55
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                        className: "p-3 text-left",
                        children: "Description"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 242,
                        columnNumber: 94
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                        className: "p-3 text-left",
                        children: "Category"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 242,
                        columnNumber: 140
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                        className: "p-3 text-right",
                        children: "Amount"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                        lineNumber: 242,
                        columnNumber: 183
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 242,
                columnNumber: 51
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 242,
            columnNumber: 11
        }, this);
        $[41] = t28;
    } else {
        t28 = $[41];
    }
    const t29 = "p-3 text-right";
    const t30 = "\u20B9";
    const t31 = filtered.reduce(_OverviewPageFilteredReduce, 0).toLocaleString();
    let t32;
    if ($[42] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
            className: t29,
            children: [
                t30,
                t31
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
            lineNumber: 252,
            columnNumber: 11
        }, this);
        $[42] = t31;
        $[43] = t32;
    } else {
        t32 = $[43];
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-8",
        children: [
            t19,
            t22,
            t27,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "p-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                    className: "min-w-full text-sm",
                    children: [
                        t28,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                            children: filtered.map(_OverviewPageFilteredMap)
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 258,
                            columnNumber: 117
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tfoot", {
                            className: "bg-slate-50 border-t font-semibold",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                        className: "p-3",
                                        colSpan: 3,
                                        children: [
                                            "Total (",
                                            filtered.length,
                                            " items)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                                        lineNumber: 258,
                                        columnNumber: 230
                                    }, this),
                                    t32
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                                lineNumber: 258,
                                columnNumber: 226
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                            lineNumber: 258,
                            columnNumber: 172
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                    lineNumber: 258,
                    columnNumber: 74
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 258,
                columnNumber: 52
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
        lineNumber: 258,
        columnNumber: 10
    }, this);
}
_s(OverviewPage, "42GASUL8pX2/N6Oh5HTh0GvQEF0=");
_c = OverviewPage;
function _OverviewPageFilteredReduce(s_1, x_1) {
    return s_1 + (x_1.type === "Expense" ? -x_1.amount : x_1.amount);
}
function _OverviewPageFilteredMap(t_2) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
        className: "border-b hover:bg-slate-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_2.date
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 264,
                columnNumber: 66
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_2.desc
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 264,
                columnNumber: 101
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: "p-3",
                children: t_2.category
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 264,
                columnNumber: 136
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                className: `p-3 text-right font-medium ${t_2.type === "Income" ? "text-emerald-600" : "text-rose-600"}`,
                children: [
                    t_2.type === "Expense" ? "-" : "+",
                    "₹",
                    t_2.amount
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
                lineNumber: 264,
                columnNumber: 175
            }, this)
        ]
    }, t_2.id, true, {
        fileName: "[project]/app/tools/finance/budget-ultimate/page.tsx",
        lineNumber: 264,
        columnNumber: 10
    }, this);
}
function _OverviewPageAnonymous2(s_0, x_0) {
    return s_0 + x_0.amount;
}
function _OverviewPageTransactionsFilter2(t_0) {
    return t_0.type === "Expense";
}
function _OverviewPageAnonymous(s, x) {
    return s + x.amount;
}
function _OverviewPageTransactionsFilter(t) {
    return t.type === "Income";
}
var _c;
__turbopack_context__.k.register(_c, "OverviewPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_tools_finance_budget-ultimate_f9ffae69._.js.map