(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_tools_finance_budget-tracker_page_tsx_4b328353._.js",
  "static/chunks/node_modules_recharts_es6_util_1136112b._.js",
  "static/chunks/node_modules_recharts_es6_state_b98ae00d._.js",
  "static/chunks/node_modules_recharts_es6_component_8b30ff53._.js",
  "static/chunks/node_modules_recharts_es6_cartesian_7fc7b21e._.js",
  "static/chunks/node_modules_recharts_es6_96237fc2._.js",
  "static/chunks/node_modules_xlsx_xlsx_mjs_fef98e92._.js",
  "static/chunks/node_modules_4fe629ef._.js",
  "static/chunks/node_modules_react-toastify_dist_ReactToastify_487faac8.css"
],
    source: "dynamic"
});
