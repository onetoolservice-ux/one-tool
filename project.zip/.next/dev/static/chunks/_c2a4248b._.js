(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/tools/finance/budget-ultimate/components/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
;
;
function Card(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "f45420678617ef103bf58eb9594e9c8b398652b8c53bc0299d73a1d4de87218e") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f45420678617ef103bf58eb9594e9c8b398652b8c53bc0299d73a1d4de87218e";
    }
    const { children, className: t1 } = t0;
    const className = t1 === undefined ? "" : t1;
    const t2 = `bg-white border rounded-xl p-5 ${className}`;
    let t3;
    if ($[1] !== children || $[2] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t2,
            children: children
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Card.tsx",
            lineNumber: 18,
            columnNumber: 10
        }, this);
        $[1] = children;
        $[2] = t2;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    return t3;
}
_c = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Drawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function Drawer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(53);
    if ($[0] !== "2f03a659d44c3923b4306fbcf58f86382cfe67cc47763dce77cf9e9f1af1a650") {
        for(let $i = 0; $i < 53; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2f03a659d44c3923b4306fbcf58f86382cfe67cc47763dce77cf9e9f1af1a650";
    }
    const { open, onClose, defaultData } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            name: "",
            amount: "",
            color: "#000000",
            type: "Expense"
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [form, setForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    let t3;
    if ($[2] !== defaultData) {
        t2 = ({
            "Drawer[useEffect()]": ()=>{
                if (defaultData) {
                    setForm(defaultData);
                }
            }
        })["Drawer[useEffect()]"];
        t3 = [
            defaultData
        ];
        $[2] = defaultData;
        $[3] = t2;
        $[4] = t3;
    } else {
        t2 = $[3];
        t3 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    if (!open) {
        return null;
    }
    let t4;
    if ($[5] !== onClose) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 bg-black/20 z-40",
            onClick: onClose
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 56,
            columnNumber: 10
        }, this);
        $[5] = onClose;
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const t5 = defaultData ? "Edit Category" : "Add Category";
    let t6;
    if ($[7] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-xl font-semibold",
            children: t5
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 65,
            columnNumber: 10
        }, this);
        $[7] = t5;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
            size: 22
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 73,
            columnNumber: 10
        }, this);
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== onClose) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: onClose,
            className: "p-1",
            children: t7
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[10] = onClose;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== t6 || $[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-between mb-6",
            children: [
                t6,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 88,
            columnNumber: 10
        }, this);
        $[12] = t6;
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-slate-500",
            children: "Name"
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 97,
            columnNumber: 11
        }, this);
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] !== form) {
        t11 = ({
            "Drawer[<input>.onChange]": (e)=>setForm({
                    ...form,
                    name: e.target.value
                })
        })["Drawer[<input>.onChange]"];
        $[16] = form;
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] !== form.name || $[19] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t10,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    className: "w-full mt-1 border px-3 py-2 rounded-lg",
                    value: form.name,
                    onChange: t11
                }, void 0, false, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
                    lineNumber: 117,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 117,
            columnNumber: 11
        }, this);
        $[18] = form.name;
        $[19] = t11;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-slate-500",
            children: "Type"
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 126,
            columnNumber: 11
        }, this);
        $[21] = t13;
    } else {
        t13 = $[21];
    }
    let t14;
    if ($[22] !== form) {
        t14 = ({
            "Drawer[<select>.onChange]": (e_0)=>setForm({
                    ...form,
                    type: e_0.target.value
                })
        })["Drawer[<select>.onChange]"];
        $[22] = form;
        $[23] = t14;
    } else {
        t14 = $[23];
    }
    let t15;
    let t16;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            children: "Expense"
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 147,
            columnNumber: 11
        }, this);
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            children: "Income"
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 148,
            columnNumber: 11
        }, this);
        $[24] = t15;
        $[25] = t16;
    } else {
        t15 = $[24];
        t16 = $[25];
    }
    let t17;
    if ($[26] !== form.type || $[27] !== t14) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t13,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                    className: "w-full mt-1 border px-3 py-2 rounded-lg",
                    value: form.type,
                    onChange: t14,
                    children: [
                        t15,
                        t16
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
                    lineNumber: 157,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 157,
            columnNumber: 11
        }, this);
        $[26] = form.type;
        $[27] = t14;
        $[28] = t17;
    } else {
        t17 = $[28];
    }
    let t18;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-slate-500",
            children: "Amount (optional)"
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 166,
            columnNumber: 11
        }, this);
        $[29] = t18;
    } else {
        t18 = $[29];
    }
    let t19;
    if ($[30] !== form) {
        t19 = ({
            "Drawer[<input>.onChange]": (e_1)=>setForm({
                    ...form,
                    amount: Number(e_1.target.value)
                })
        })["Drawer[<input>.onChange]"];
        $[30] = form;
        $[31] = t19;
    } else {
        t19 = $[31];
    }
    let t20;
    if ($[32] !== form.amount || $[33] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t18,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    className: "w-full mt-1 border px-3 py-2 rounded-lg",
                    type: "number",
                    value: form.amount,
                    onChange: t19
                }, void 0, false, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
                    lineNumber: 186,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[32] = form.amount;
        $[33] = t19;
        $[34] = t20;
    } else {
        t20 = $[34];
    }
    let t21;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: "text-sm text-slate-500",
            children: "Color"
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 195,
            columnNumber: 11
        }, this);
        $[35] = t21;
    } else {
        t21 = $[35];
    }
    let t22;
    if ($[36] !== form) {
        t22 = ({
            "Drawer[<input>.onChange]": (e_2)=>setForm({
                    ...form,
                    color: e_2.target.value
                })
        })["Drawer[<input>.onChange]"];
        $[36] = form;
        $[37] = t22;
    } else {
        t22 = $[37];
    }
    let t23;
    if ($[38] !== form.color || $[39] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t21,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "color",
                    className: "w-16 h-10 mt-1 border rounded",
                    value: form.color,
                    onChange: t22
                }, void 0, false, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
                    lineNumber: 215,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 215,
            columnNumber: 11
        }, this);
        $[38] = form.color;
        $[39] = t22;
        $[40] = t23;
    } else {
        t23 = $[40];
    }
    let t24;
    if ($[41] !== t12 || $[42] !== t17 || $[43] !== t20 || $[44] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-4 flex-1 overflow-y-auto",
            children: [
                t12,
                t17,
                t20,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 224,
            columnNumber: 11
        }, this);
        $[41] = t12;
        $[42] = t17;
        $[43] = t20;
        $[44] = t23;
        $[45] = t24;
    } else {
        t24 = $[45];
    }
    let t25;
    if ($[46] === Symbol.for("react.memo_cache_sentinel")) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            className: "w-full py-3 bg-black text-white rounded-lg mt-4",
            children: "Save"
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 235,
            columnNumber: 11
        }, this);
        $[46] = t25;
    } else {
        t25 = $[46];
    }
    let t26;
    if ($[47] !== t24 || $[48] !== t9) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed right-0 top-0 h-full w-full sm:w-96 bg-white shadow-xl z-50 p-6 flex flex-col",
            children: [
                t9,
                t24,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx",
            lineNumber: 242,
            columnNumber: 11
        }, this);
        $[47] = t24;
        $[48] = t9;
        $[49] = t26;
    } else {
        t26 = $[49];
    }
    let t27;
    if ($[50] !== t26 || $[51] !== t4) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t4,
                t26
            ]
        }, void 0, true);
        $[50] = t26;
        $[51] = t4;
        $[52] = t27;
    } else {
        t27 = $[52];
    }
    return t27;
}
_s(Drawer, "GxSN9DB/+mhMjSiggrDfRIJpW70=");
_c = Drawer;
var _c;
__turbopack_context__.k.register(_c, "Drawer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/utils/sampleCategories.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const __TURBOPACK__default__export__ = [
    {
        id: 1,
        name: "Groceries",
        type: "Expense",
        amount: 1200,
        color: "#ff6565"
    },
    {
        id: 2,
        name: "Fuel",
        type: "Expense",
        amount: 900,
        color: "#ff9f43"
    },
    {
        id: 3,
        name: "Snacks",
        type: "Expense",
        amount: 250,
        color: "#ffcd3c"
    },
    {
        id: 4,
        name: "Salary",
        type: "Income",
        amount: 35000,
        color: "#34c759"
    },
    {
        id: 5,
        name: "Freelance",
        type: "Income",
        amount: 8000,
        color: "#0dcaf0"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/tools/finance/budget-ultimate/categories/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CategoriesPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/components/Drawer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/tools/finance/budget-ultimate/utils/sampleCategories.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function CategoriesPage() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(52);
    if ($[0] !== "c2f1dde0284f0c21f587315693ccbe76eede4ec834138c3be50fea24ce38e189") {
        for(let $i = 0; $i < 52; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c2f1dde0284f0c21f587315693ccbe76eede4ec834138c3be50fea24ce38e189";
    }
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [drawerOpen, setDrawerOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let T0;
    let t0;
    let t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    if ($[1] !== search) {
        const filtered = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$utils$2f$sampleCategories$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].filter({
            "CategoriesPage[sampleCategories.filter()]": (c)=>c.name.toLowerCase().includes(search.toLowerCase())
        }["CategoriesPage[sampleCategories.filter()]"]);
        const totalExpense = filtered.filter(_CategoriesPageFilteredFilter).reduce(_CategoriesPageAnonymous, 0);
        const totalIncome = filtered.filter(_CategoriesPageFilteredFilter2).reduce(_CategoriesPageAnonymous2, 0);
        t5 = "space-y-8";
        if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
            t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-3xl font-bold text-slate-900",
                        children: "Categories"
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                        lineNumber: 39,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-slate-500 mt-1",
                        children: "Organize spending into groups."
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                        lineNumber: 39,
                        columnNumber: 82
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 39,
                columnNumber: 12
            }, this);
            $[12] = t6;
        } else {
            t6 = $[12];
        }
        let t9;
        if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
            t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                size: 18,
                className: "absolute left-3 top-2.5 text-slate-400"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 46,
                columnNumber: 12
            }, this);
            $[13] = t9;
        } else {
            t9 = $[13];
        }
        let t10;
        if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
            t10 = ({
                "CategoriesPage[<input>.onChange]": (e)=>setSearch(e.target.value)
            })["CategoriesPage[<input>.onChange]"];
            $[14] = t10;
        } else {
            t10 = $[14];
        }
        const t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            className: "w-full pl-10 pr-3 py-2 border rounded-lg text-sm",
            placeholder: "Search categories...",
            value: search,
            onChange: t10
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 60,
            columnNumber: 17
        }, this);
        let t12;
        if ($[15] !== t11) {
            t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full lg:w-80",
                children: [
                    t9,
                    t11
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 63,
                columnNumber: 13
            }, this);
            $[15] = t11;
            $[16] = t12;
        } else {
            t12 = $[16];
        }
        let t13;
        if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
            t13 = ({
                "CategoriesPage[<button>.onClick]": ()=>{
                    setSelected(null);
                    setDrawerOpen(true);
                }
            })["CategoriesPage[<button>.onClick]"];
            $[17] = t13;
        } else {
            t13 = $[17];
        }
        let t14;
        if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
            t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: t13,
                className: "px-4 py-2 bg-black text-white rounded-lg flex items-center gap-2 text-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                        size: 15
                    }, void 0, false, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                        lineNumber: 83,
                        columnNumber: 120
                    }, this),
                    " Add Category"
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 83,
                columnNumber: 13
            }, this);
            $[18] = t14;
        } else {
            t14 = $[18];
        }
        if ($[19] !== t12) {
            t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "py-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col lg:flex-row lg:items-center justify-between gap-4",
                    children: [
                        t12,
                        t14
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                    lineNumber: 89,
                    columnNumber: 35
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 89,
                columnNumber: 12
            }, this);
            $[19] = t12;
            $[20] = t7;
        } else {
            t7 = $[20];
        }
        let t15;
        if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
            t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-slate-500",
                children: "Total Expense Categories"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 97,
                columnNumber: 13
            }, this);
            $[21] = t15;
        } else {
            t15 = $[21];
        }
        const t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t15,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-xl font-bold mt-1",
                    children: [
                        "₹",
                        totalExpense.toLocaleString()
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                    lineNumber: 102,
                    columnNumber: 28
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 102,
            columnNumber: 17
        }, this);
        let t17;
        if ($[22] === Symbol.for("react.memo_cache_sentinel")) {
            t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-xs text-slate-500",
                children: "Total Income Categories"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 105,
                columnNumber: 13
            }, this);
            $[22] = t17;
        } else {
            t17 = $[22];
        }
        const t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            children: [
                t17,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-xl font-bold mt-1",
                    children: [
                        "₹",
                        totalIncome.toLocaleString()
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                    lineNumber: 110,
                    columnNumber: 28
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 110,
            columnNumber: 17
        }, this);
        if ($[23] !== t16 || $[24] !== t18) {
            t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
                children: [
                    t16,
                    t18
                ]
            }, void 0, true, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 112,
                columnNumber: 12
            }, this);
            $[23] = t16;
            $[24] = t18;
            $[25] = t8;
        } else {
            t8 = $[25];
        }
        T0 = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
        t4 = "overflow-auto";
        t2 = "min-w-full text-sm";
        if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                className: "bg-slate-50 text-left border-b",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3",
                            children: "Name"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                            lineNumber: 123,
                            columnNumber: 66
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3",
                            children: "Type"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                            lineNumber: 123,
                            columnNumber: 95
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3",
                            children: "Color"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                            lineNumber: 123,
                            columnNumber: 124
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-right",
                            children: "Amount"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                            lineNumber: 123,
                            columnNumber: 154
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                            className: "p-3 text-right",
                            children: "Actions"
                        }, void 0, false, {
                            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                            lineNumber: 123,
                            columnNumber: 196
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                    lineNumber: 123,
                    columnNumber: 62
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 123,
                columnNumber: 12
            }, this);
            $[26] = t3;
        } else {
            t3 = $[26];
        }
        t0 = filtered.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                colSpan: 5,
                className: "text-center py-10 text-slate-400",
                children: "No categories found"
            }, void 0, false, {
                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                lineNumber: 128,
                columnNumber: 39
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 128,
            columnNumber: 35
        }, this);
        let t19;
        if ($[27] === Symbol.for("react.memo_cache_sentinel")) {
            t19 = ({
                "CategoriesPage[filtered.map()]": (c_4)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                        className: "border-b hover:bg-slate-50 cursor-pointer",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                className: "p-3 font-medium",
                                children: c_4.name
                            }, void 0, false, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                                lineNumber: 132,
                                columnNumber: 121
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                className: "p-3",
                                children: c_4.type
                            }, void 0, false, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                                lineNumber: 132,
                                columnNumber: 168
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                className: "p-3",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "inline-block w-4 h-4 rounded",
                                    style: {
                                        backgroundColor: c_4.color
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                                    lineNumber: 132,
                                    columnNumber: 223
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                                lineNumber: 132,
                                columnNumber: 203
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                className: "p-3 text-right",
                                children: [
                                    c_4.type === "Expense" ? "-" : "+",
                                    "₹",
                                    c_4.amount
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                                lineNumber: 134,
                                columnNumber: 23
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                className: "p-3 text-right",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "text-blue-600 hover:underline",
                                    onClick: {
                                        "CategoriesPage[filtered.map() > <button>.onClick]": ()=>{
                                            setSelected(c_4);
                                            setDrawerOpen(true);
                                        }
                                    }["CategoriesPage[filtered.map() > <button>.onClick]"],
                                    children: "Edit"
                                }, void 0, false, {
                                    fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                                    lineNumber: 134,
                                    columnNumber: 139
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                                lineNumber: 134,
                                columnNumber: 108
                            }, this)
                        ]
                    }, c_4.id, true, {
                        fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
                        lineNumber: 132,
                        columnNumber: 50
                    }, this)
            })["CategoriesPage[filtered.map()]"];
            $[27] = t19;
        } else {
            t19 = $[27];
        }
        t1 = filtered.map(t19);
        $[1] = search;
        $[2] = T0;
        $[3] = t0;
        $[4] = t1;
        $[5] = t2;
        $[6] = t3;
        $[7] = t4;
        $[8] = t5;
        $[9] = t6;
        $[10] = t7;
        $[11] = t8;
    } else {
        T0 = $[2];
        t0 = $[3];
        t1 = $[4];
        t2 = $[5];
        t3 = $[6];
        t4 = $[7];
        t5 = $[8];
        t6 = $[9];
        t7 = $[10];
        t8 = $[11];
    }
    let t9;
    if ($[28] !== t0 || $[29] !== t1) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
            children: [
                t0,
                t1
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 171,
            columnNumber: 10
        }, this);
        $[28] = t0;
        $[29] = t1;
        $[30] = t9;
    } else {
        t9 = $[30];
    }
    let t10;
    if ($[31] !== t2 || $[32] !== t3 || $[33] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
            className: t2,
            children: [
                t3,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 180,
            columnNumber: 11
        }, this);
        $[31] = t2;
        $[32] = t3;
        $[33] = t9;
        $[34] = t10;
    } else {
        t10 = $[34];
    }
    let t11;
    if ($[35] !== t10 || $[36] !== t4) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t4,
            children: t10
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 190,
            columnNumber: 11
        }, this);
        $[35] = t10;
        $[36] = t4;
        $[37] = t11;
    } else {
        t11 = $[37];
    }
    let t12;
    if ($[38] !== T0 || $[39] !== t11) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(T0, {
            children: t11
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 199,
            columnNumber: 11
        }, this);
        $[38] = T0;
        $[39] = t11;
        $[40] = t12;
    } else {
        t12 = $[40];
    }
    let t13;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = ({
            "CategoriesPage[<Drawer>.onClose]": ()=>setDrawerOpen(false)
        })["CategoriesPage[<Drawer>.onClose]"];
        $[41] = t13;
    } else {
        t13 = $[41];
    }
    let t14;
    if ($[42] !== drawerOpen || $[43] !== selected) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$tools$2f$finance$2f$budget$2d$ultimate$2f$components$2f$Drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            open: drawerOpen,
            onClose: t13,
            defaultData: selected
        }, void 0, false, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 217,
            columnNumber: 11
        }, this);
        $[42] = drawerOpen;
        $[43] = selected;
        $[44] = t14;
    } else {
        t14 = $[44];
    }
    let t15;
    if ($[45] !== t12 || $[46] !== t14 || $[47] !== t5 || $[48] !== t6 || $[49] !== t7 || $[50] !== t8) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t5,
            children: [
                t6,
                t7,
                t8,
                t12,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/app/tools/finance/budget-ultimate/categories/page.tsx",
            lineNumber: 226,
            columnNumber: 11
        }, this);
        $[45] = t12;
        $[46] = t14;
        $[47] = t5;
        $[48] = t6;
        $[49] = t7;
        $[50] = t8;
        $[51] = t15;
    } else {
        t15 = $[51];
    }
    return t15;
}
_s(CategoriesPage, "2zHajPsnkGFeh3wDvRf1sA3Rrvg=");
_c = CategoriesPage;
function _CategoriesPageAnonymous2(s_0, c_3) {
    return s_0 + c_3.amount;
}
function _CategoriesPageFilteredFilter2(c_2) {
    return c_2.type === "Income";
}
function _CategoriesPageAnonymous(s, c_1) {
    return s + c_1.amount;
}
function _CategoriesPageFilteredFilter(c_0) {
    return c_0.type === "Expense";
}
var _c;
__turbopack_context__.k.register(_c, "CategoriesPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.555.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Plus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M5 12h14",
            key: "1ays0h"
        }
    ],
    [
        "path",
        {
            d: "M12 5v14",
            key: "s699le"
        }
    ]
];
const Plus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("plus", __iconNode);
;
 //# sourceMappingURL=plus.js.map
}),
"[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Plus",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=_c2a4248b._.js.map