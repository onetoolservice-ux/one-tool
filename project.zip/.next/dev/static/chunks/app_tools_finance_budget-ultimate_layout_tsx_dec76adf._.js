(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_tools_finance_budget-ultimate_components_NavbarTabs_tsx_a6c9a78e._.js"
],
    source: "dynamic"
});
